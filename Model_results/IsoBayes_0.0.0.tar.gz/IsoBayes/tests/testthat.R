library(testthat)
library(IsoBayes)
test_check("IsoBayes")
